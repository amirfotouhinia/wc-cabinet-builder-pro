<?php
add_action('woocommerce_before_add_to_cart_button', 'wccb_attach_section_fields');
function wccb_attach_section_fields() {
    global $product;
    if ($product->get_slug() !== 'attach-section') return;
    ?>
    <div class="wccb-attach-section">
        <h3>Attach Section - Build Multi-Cabinet Unit</h3>
        
        <label>Number of Columns: 
            <input type="number" id="wccb_columns_count" min="2" max="5" value="2">
        </label>
        
        <div id="wccb_columns_container"></div>
        
        <p><strong>Total Price: $<span id="wccb_attach_total">0</span></strong></p>
        <input type="hidden" name="wccb_attach_data" id="wccb_attach_data" value="">
    </div>
    
    <script>
    function renderColumns() {
        var count = parseInt(jQuery('#wccb_columns_count').val()) || 2;
        var container = jQuery('#wccb_columns_container');
        container.empty();
        
        for (var i = 0; i < count; i++) {
            var column = jQuery('<div>', { class: 'wccb_column', style: 'border:1px solid #ddd; margin:15px 0; padding:15px; border-radius:6px;' });
            column.append('<h4>Column ' + (i+1) + '</h4>');
            
            var typeSelect = jQuery('<select>', { class: 'wccb_column_type' });
            typeSelect.append('<option value="hanging">Hanging System (72")</option>');
            typeSelect.append('<option value="84">Start From Floor 84"</option>');
            typeSelect.append('<option value="96" selected>Start From Floor 96"</option>');
            column.append(jQuery('<p>').append(jQuery('<label>Cabinet Type: </label>')).append(typeSelect));
            
            var depthSelect = jQuery('<select>', { class: 'wccb_column_depth' });
            depthSelect.append('<option value="12">Depth 12"</option>');
            depthSelect.append('<option value="16" selected>Depth 16"</option>');
            depthSelect.append('<option value="24">Depth 24"</option>');
            column.append(jQuery('<p>').append(jQuery('<label>Depth: </label>')).append(depthSelect));
            
            var widthInput = jQuery('<input>', { type: 'number', class: 'wccb_column_width', min: 15, max: 40, value: 25, style: 'width:80px;' });
            column.append(jQuery('<p>').append(jQuery('<label>Width (inches): </label>')).append(widthInput));
            
            var drawerDiv = jQuery('<div>');
            drawerDiv.append(jQuery('<label>Number of Drawers: </label>'));
            var drawerCount = jQuery('<input>', { type: 'number', class: 'wccb_column_drawer_count', min: 0, max: 10, value: 0, style: 'width:80px;' });
            drawerDiv.append(drawerCount);
            drawerDiv.append('<div class="wccb_column_drawers_list"></div>');
            column.append(drawerDiv);
            
            column.append(jQuery('<p>').append(jQuery('<label>Shelves: </label>')).append(
                jQuery('<input>', { type: 'number', class: 'wccb_column_shelves', min: 0, max: 5, value: 0, style: 'width:80px;' })
            ));
            
            var backSelect = jQuery('<select>', { class: 'wccb_column_back' });
            backSelect.append('<option value="0">No Back Panel</option>');
            backSelect.append('<option value="1">Yes Back Panel</option>');
            column.append(jQuery('<p>').append(jQuery('<label>Back Panel: </label>')).append(backSelect));
            
            var colorSelect = jQuery('<select>', { class: 'wccb_column_color' });
            colorSelect.append('<option value="white">White</option>');
            colorSelect.append('<option value="gray">Gray</option>');
            colorSelect.append('<option value="oak">Oak</option>');
            colorSelect.append('<option value="other">Other</option>');
            column.append(jQuery('<p>').append(jQuery('<label>Color: </label>')).append(colorSelect));
            
            container.append(column);
        }
        
        attachEvents();
        updateAttachPrice();
    }
    
    function attachEvents() {
        jQuery('.wccb_column_type, .wccb_column_depth, .wccb_column_width, .wccb_column_shelves, .wccb_column_back, .wccb_column_color').off('change').on('change', updateAttachPrice);
        jQuery('.wccb_column_drawer_count').off('input').on('input', function() {
            updateDrawerList(jQuery(this));
            updateAttachPrice();
        });
    }
    
    function updateDrawerList($countInput) {
        var $column = $countInput.closest('.wccb_column');
        var count = parseInt($countInput.val()) || 0;
        var $list = $column.find('.wccb_column_drawers_list');
        $list.empty();
        
        for (var i = 0; i < count; i++) {
            var select = jQuery('<select>', { class: 'wccb_column_drawer_height' });
            select.append(jQuery('<option>', { value: 6, text: '6 inches' }));
            select.append(jQuery('<option>', { value: 8, text: '8 inches', selected: true }));
            select.append(jQuery('<option>', { value: 12, text: '12 inches' }));
            $list.append(jQuery('<div>').append(jQuery('<span>', { text: 'Drawer ' + (i+1) + ': ' })).append(select));
        }
        $list.find('.wccb_column_drawer_height').off('change').on('change', updateAttachPrice);
    }
    
    function getColumnsData() {
        var cabinets = [];
        jQuery('.wccb_column').each(function() {
            var $col = jQuery(this);
            var drawers = [];
            $col.find('.wccb_column_drawer_height').each(function() {
                drawers.push(parseInt(jQuery(this).val()));
            });
            cabinets.push({
                type: $col.find('.wccb_column_type').val(),
                depth: parseInt($col.find('.wccb_column_depth').val()),
                width: parseInt($col.find('.wccb_column_width').val()),
                drawers: drawers,
                shelves: parseInt($col.find('.wccb_column_shelves').val()),
                back_panel: parseInt($col.find('.wccb_column_back').val()),
                color: $col.find('.wccb_column_color').val()
            });
        });
        return cabinets;
    }
    
    function updateAttachPrice() {
        var cabinets = getColumnsData();
        jQuery.ajax({
            url: wccb_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'wccb_calculate_attach_price',
                nonce: wccb_ajax.nonce,
                cabinets: JSON.stringify(cabinets)
            },
            success: function(response) {
                if (response.success) {
                    jQuery('#wccb_attach_total').text(response.data.price);
                    jQuery('#wccb_attach_data').val(JSON.stringify(cabinets));
                }
            }
        });
    }
    
    jQuery('#wccb_columns_count').on('input', renderColumns);
    jQuery(document).ready(renderColumns);
    </script>
    <?php
}

add_action('wp_ajax_wccb_calculate_attach_price', 'wccb_ajax_calculate_attach_price');
add_action('wp_ajax_nopriv_wccb_calculate_attach_price', 'wccb_ajax_calculate_attach_price');
function wccb_ajax_calculate_attach_price() {
    check_ajax_referer('wccb_calculate', 'nonce');
    $cabinets = json_decode(stripslashes($_POST['cabinets']), true);
    
    if (empty($cabinets)) {
        wp_send_json_error(['message' => 'No cabinets selected.']);
    }
    
    try {
        $price = wccb_calculate_attach_section_price($cabinets);
        wp_send_json_success(['price' => $price]);
    } catch (Exception $e) {
        wp_send_json_error(['message' => $e->getMessage()]);
    }
}